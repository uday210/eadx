({
	handlePlatformEvent: function(component, event, helper) {
        helper.handlePlatformEvent(component, event);
	},
    
    test: function(component, event, helper) {
        helper.updateSelection(component, true, '0FKB000000092VyOAI');
	}

})
({
	myAction : function() {

	}
})
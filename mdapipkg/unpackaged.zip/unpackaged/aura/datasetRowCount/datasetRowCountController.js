({
	init: function(component, event, helper) {
		
	},
    
	countDatasetRows: function(component, event, helper) {
		helper.countDatasetRows(component);	
	}
    
})
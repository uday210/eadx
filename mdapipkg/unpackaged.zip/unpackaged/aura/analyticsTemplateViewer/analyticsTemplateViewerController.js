({
    handleTemplateIdChange: function(component, event, helper) {
        var templateId = component.get('v.templateId');
	}
})
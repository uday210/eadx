({
	setup: function(component) {
        console.warn('helper.setup');
        let els = document.querySelector('.waveError');
        console.warn('els: ', els);
	}
})
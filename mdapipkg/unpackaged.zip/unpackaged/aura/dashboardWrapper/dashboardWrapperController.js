({
	check: function(component, event, helper) {
		helper.setup(component);
	}
})
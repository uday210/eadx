({
	gotoPage2: function(component, event, helper) {
		var dashboard = component.find('dashboard');
        dashboard.set('v.pageId', 'shit');
	},
})
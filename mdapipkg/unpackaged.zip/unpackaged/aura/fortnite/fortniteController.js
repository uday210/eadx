({
    handleGetPlayers: function (component, event, helper) {
        helper.getPlayers(component, event);
    },
    
    handleGetPlayerInfo: function (component, event, helper) {
        helper.getPlayerInfo(component, event);
    },
    
    handleGetPlayerInfo2: function (component, event, helper) {
        helper.getPlayerInfo2(component, event);
    },

    handleGetPlayerData: function (component, event, helper) {
        helper.getPlayerData(component, event);
    },
    
    handleGetPlayerData2: function (component, event, helper) {
        helper.getPlayerData2(component, event);
    },
    
    handleGetStore: function (component, event, helper) {
        helper.getStore(component, event);
    }    
})